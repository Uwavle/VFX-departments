Usage
=====

Here you can find information about how you can use Cinemagoer in your own
programs.

.. warning::

   This document is far from complete: the code is the final documentation! ;-)


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   quickstart
   data-interface
   role
   series
   adult
   info2xml
   l10n
   access
   s3
   ptdf
