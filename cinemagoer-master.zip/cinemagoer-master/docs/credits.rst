Contributors
============

.. include:: ../CONTRIBUTORS.txt

.. raw:: html

   <h2>Credits</h2>

.. include:: ../CREDITS.txt
