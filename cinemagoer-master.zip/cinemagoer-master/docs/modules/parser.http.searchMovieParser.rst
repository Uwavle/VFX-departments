:orphan:

:mod:`imdb.parser.http.searchMovieParser`
=========================================

.. automodule:: imdb.parser.http.searchMovieParser
   :members:
