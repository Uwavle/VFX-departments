:orphan:

:mod:`imdb.parser.sql.dbschema`
===============================

.. automodule:: imdb.parser.sql.dbschema
   :members:
