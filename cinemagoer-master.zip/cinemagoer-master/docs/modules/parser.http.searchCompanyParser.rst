:orphan:

:mod:`imdb.parser.http.searchCompanyParser`
===========================================

.. automodule:: imdb.parser.http.searchCompanyParser
   :members:
