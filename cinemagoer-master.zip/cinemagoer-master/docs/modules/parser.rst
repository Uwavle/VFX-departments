:orphan:

:mod:`imdb.parser`
==================

.. automodule:: imdb.parser
