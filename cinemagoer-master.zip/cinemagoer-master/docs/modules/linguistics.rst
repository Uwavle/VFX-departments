:orphan:

:mod:`imdb.linguistics`
=======================

.. automodule:: imdb.linguistics
   :members:
